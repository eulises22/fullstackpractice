module.exports = 
{
    googleClientID: '808829131515-253d90lfi5q1hdql9e9ltor6tibj8uu8.apps.googleusercontent.com',
    googleClientSecret: '0rXGjmoXuzaxnHbs85zkQmA-',
    mongoURI: 'mongodb://ulyses:password1@ds211724.mlab.com:11724/emaily-dev'
};